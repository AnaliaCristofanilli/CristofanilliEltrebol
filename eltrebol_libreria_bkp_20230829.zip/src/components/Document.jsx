import { useEffect, useState } from "react";
import { doc, getDoc, getFirestore } from "firebase/firestore";

// eslint-disable-next-line react/prop-types
const Document = ({ idDB }) => {
  const [product, setProduct] = useState([]);

  useEffect(() => {
    const db = getFirestore();
    //const oneItem = doc(db, "productos", "Adsm5PfvE6riUZ8yVFoF");
    const oneItem = doc(db, "productos", `${idDB}`);
    getDoc(oneItem).then((snapshot) => {
      if (snapshot.exists()) {
        const doc = snapshot.data();
        setProduct({ idDB: snapshot.id, ...doc });
      }
    });
  }, []);
  console.log(product);
  return (
    <div>
      <h5>Producto</h5>
      <p>Nombre: {product.nombre}</p>
      <p>Descripcion: {product.descripcion}</p>
      <p>Precio: {product.precio}</p>
      <p>Stock: {product.stock}</p>
      <p>Foto: {product.pictureUrl}</p>
      <p>Categoria: {product.categoria}</p>
      <p>Codigo: {product.id}</p>
      <p>id: {product.idDB}</p>
    </div>
  );
};

export default Document;

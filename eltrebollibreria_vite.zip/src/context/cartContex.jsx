/* eslint-disable react/prop-types */
import { createContext, useState } from "react";

export const CartContext = createContext(null);
export const CartProvider = ({ children }) => {
  const [cart, setCart] = useState([]);
  const longitud = cart.length;

  const addCart = (item) => {
    console.log(item);

    const producto = cart.find((p)=>())

    setCart((cart) => [...cart, item]); //agrega producto al final del arreglo
    /*setCart((prevState) => ({
    data: [...prevState.data.slice(0,index), ...prevState.data.slice(index+1)]
  }))*/
    //eliminar producto
    setCart((current) => current.filter((producto) => producto.id !== 2));
  };

  return (
    <CartContext.Provider value={{ cart, addCart, longitud }}>
      {children}
    </CartContext.Provider>
  );
};

export default CartContext;

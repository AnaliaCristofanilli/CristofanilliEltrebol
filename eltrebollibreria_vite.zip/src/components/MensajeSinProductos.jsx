const MensajeSinProductos = () => {
  return <div>MensajeSinProductos</div>;
};

export default MensajeSinProductos;

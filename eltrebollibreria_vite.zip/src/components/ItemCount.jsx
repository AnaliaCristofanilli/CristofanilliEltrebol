/* eslint-disable react/prop-types */
import InputGroup from "react-bootstrap/InputGroup";
import Button from "react-bootstrap/Button";
import { Form } from "react-bootstrap";
import { useState, useContext } from "react";
import CartContext from "../context/cartContex";

const ItemCount = (props) => {
  const { id, stock } = props;
  const [contador, setContador] = useState(0);
  const { addCart } = useContext(CartContext);
  const sumar = () => {
    if (contador + 1 <= stock) setContador(contador + 1);
  };
  const restar = () => {
    if (contador - 1 >= 0) setContador(contador - 1);
  };
  const verificarCantidad = (e) => {
    if (e <= stock) setContador(e);
  };
  return (
    <div>
      <InputGroup className="mb-3">
        <Button variant="outline-secondary" id="button-addon1" onClick={restar}>
          -
        </Button>
        <Form.Control
          aria-label="Cantidad"
          aria-describedby="  "
          value={contador}
          onChange={(e) => verificarCantidad(e.target.value)}
          className="text-center"
        />
        <Button variant="outline-secondary" id="button-addon1" onClick={sumar}>
          +
        </Button>
      </InputGroup>
      <div className="text-center">
        <button
          className="btn btn-success "
          disabled={contador == 0}
          onClick={() => addCart({ id: id, cantidad: contador })}
        >
          Agregar
        </button>
      </div>
    </div>
  );
};

export default ItemCount;

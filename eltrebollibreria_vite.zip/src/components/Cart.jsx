const Cart = () => {
  return (
    <div>
      <p>Detalle del carrito</p>
      <div className="container">
        <div className="row row-cols-auto">
          <div className="col">Producto</div>
          <div className="col">Cantidad</div>
          <div className="col">Descripción</div>
          <div className="col">Precio total</div>
        </div>

        <button className="btn btn-outline-success" type="submit">
          Comprar
        </button>
      </div>
    </div>
  );
};

export default Cart;

import { useEffect, useState } from "react";
import {
  collection,
  getDocs,
  getFirestore,
  query,
  where,
} from "firebase/firestore";

const Collection = () => {
  const [products, setProducts] = useState([]);
  console.log(products);

  useEffect(() => {
    const db = getFirestore();
    const itemsCollection = query(
      collection(db, "productos"),
      where("categoria", "==", "ofi")
    );
    getDocs(itemsCollection).then((snapshot) => {
      if (snapshot.size === 0) {
        console.log("No hay productos");
      }
      const docs = snapshot.docs.map((doc) => ({
        idDB: doc.id,
        ...doc.data(),
      }));
      setProducts(docs);
    });
  }, []);

  return (
    <div>
      <h4>Productos</h4>
      {products.map((product) => (
        <div key={product.id}>
          <h4>Producto: {product.nombre}</h4>
          <h5>Categoria: {product.categoria}</h5>
          <p>Precio: {product.precio}</p>
          <p>id: {product.idDB}</p>
        </div>
      ))}
    </div>
  );
};

export default Collection;
